﻿using System;

namespace Dadu
{
    class Program
    {
        static void Main(string[] args)
        {
            Intro();
            GamePlay();
            Outro();
        }

        static void Intro() 
        {
            Console.WriteLine("ADU DADU\n");
            Console.WriteLine("Selamat datang dalam permainan Adu Dadu");
            Console.WriteLine("Pada permainan Adu Dadu ini player akan berlawanan dengan komputer");
            Console.WriteLine("Permainan ini terdiri dari 10 Ronde");
            Console.WriteLine("Setiap ronde para player dan komputer akan melempar satu buah dadu");
            Console.WriteLine("Player/Komputer dengan point terbanyak setelah 10 ronde akan memenangkan permainan");
        }
        static void GamePlay() 
        {
            int daduKomputer;
            int daduPlayer;

            int jumlahRonde = 0;
            int pointKomputer = 0; 
            int pointPlayer = 0;

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("\nTekan tombol apa saja untuk memulai...\n");
                Console.ReadKey();

                jumlahRonde++;
                Console.WriteLine("Ronde " + jumlahRonde);
                daduKomputer = numbGen();
                Console.WriteLine("Komputer melempar dadu dan mendapatkan angka " + daduKomputer + ".");
                Console.ReadKey();
                daduPlayer = numbGen();
                Console.WriteLine("Player melempar dadu dan mendapatkan angka " + daduPlayer + ".");

                if (daduPlayer > daduKomputer)
                {
                    pointPlayer++;
                    Console.WriteLine("Player memenangkan ronde ini!");
                } else if (daduKomputer > daduPlayer) {
                    pointKomputer++;
                    Console.WriteLine("Komputer memenangkan ronde ini!");
                } else {
                    Console.WriteLine("Ronde ini seri!");
                }

                Console.WriteLine("Skor Player saat ini: " + pointPlayer + " || Skor Komputer saat ini: " + pointKomputer);
                Console.WriteLine("----------------------------------------------------------------------------------");
                Console.ReadKey();
                Console.Clear();
            }

            if (pointPlayer > pointKomputer)
            {
                Console.WriteLine("Selamat, player memenangkan permainan!");
            } else if (pointKomputer > pointPlayer) {
                Console.WriteLine("Komputer memenangkan permainan!");
            } else {
                Console.WriteLine("Permainan ini berakhir seri...");
            }
            Console.ReadKey();
        }
        static void Outro() 
        {
            Console.WriteLine("Nama  : -");
            Console.WriteLine("Prodi : -");
            Console.WriteLine("NIM   : -");
            Console.ReadKey();
        }
        static int numbGen() 
        {
            Random numbGen = new Random();
            int numb = numbGen.Next(1, 7);
            return numb;
        }
    }
}