﻿using System;
using System.Collections.Generic;

    namespace TebakKata
{

    class program
    {
        static string kataRahasia = "spongebob";
        static int kesempatan = 5;
        static List<string> tebakanPemain = new List<string>{};

        static void Main (string[] args)
        {
            Intro();
            MulaiMain();
            Endgame();
        }
        static void Intro()
        {
            Console.WriteLine("Selamat datang, hari ini kita akan bermain tebak kata...");
            Console.WriteLine($"Kamu mempunyai {kesempatan} kesempatan untuk menebak kata misteri hari ini");
            Console.WriteLine("petunjuknyaadalh kata ini merupakan nama film animasi");
            Console.WriteLine($"Kata ini terdiri dari {kataRahasia.Length} karakter");
            Console.WriteLine("Film apakah yang di maksud?");
        }
        static void MulaiMain()
        {
            while (kesempatan>0)
            {
                Console.Write("Apa karakter tebakanmu?(a-z) : ");
                string input = Console.ReadLine();
                tebakanPemain.Add(input);
            
                if(CekJawaban(kataRahasia, tebakanPemain))
                {
                    Console.WriteLine("selamatb kata yang anda tebak benar");
                    Console.WriteLine("Silahkan tebak huruf lainnya...");
                    Console.WriteLine(Cekhuruf(kataRahasia, tebakanPemain));
                    break;
                            
                }else if(kataRahasia.Contains(input))
                {
                    Console.WriteLine("Huruf itu tidak ada dalam kata");
                    Console.WriteLine("Silahkan tebak huruf lainnya...");
                    Console.WriteLine(Cekhuruf(kataRahasia,tebakanPemain));
                }else
                {
                    Console.WriteLine("Huruf itu tidak ada dalam kata");
                    kesempatan--;
                    Console.WriteLine($"kesempatan anda tinggal {kesempatan}");
                }               
                if(kesempatan==0)
                {
                    Console.WriteLine("mohon maaf kesempatan anda habis.");
                    Console.WriteLine($"kata misteri yang dimaksud adalah {kataRahasia}. ");
                    Console.WriteLine("Terimakasih sudah bermain...");
                    break;
                }
                static bool CekJawaban(string kataRahasia, List<string> list){
                    bool status = false;
                    for (int i = 0; i < kataRahasia.Length; i++)
                    {
                        string c = Convert.ToString(kataRahasia[i]);
                        if(list.Contains(c))
                        {
                            status = true;
                        }else
                        {
                            return status = false;
                        }
                    }
                    return status;
                }
                static string Cekhuruf(string kataRahasia, List<string> list){
                    string x = "";
                    for (int i = 0; i <kataRahasia.Length; i++)
                    {
                        string c = Convert.ToString(kataRahasia[i]);
                        if(list.Contains(c))
                        {
                            x = x + c;
                        }else
                        {                   
                            x = x + ".";  
                        }         
                    }
                    return x;
                }

            }
        }
                static void Endgame()
                {
                    Console.WriteLine();
                    Console.WriteLine("permainan berakhir");
                    Console.WriteLine($"kata msteri sebenarnya adalah {kataRahasia}");
                    Console.WriteLine("sekian Terima Kasih");
        
                }
    }
}
