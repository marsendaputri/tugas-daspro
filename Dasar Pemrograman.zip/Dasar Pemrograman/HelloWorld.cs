using System;

namespace Daspro
{
    class System
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World");
            Console.WriteLine("Teknik Informatika");
        }
    }
}